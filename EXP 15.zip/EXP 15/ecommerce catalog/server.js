const express = require('express');
const mongoose = require('mongoose');

const app = express();
app.use(express.json()); // parse JSON body

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/ecommerce')
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log(err));

// Variant Schema
const variantSchema = new mongoose.Schema({
    color: { type: String, required: true },
    size: { type: String, required: true },
    stock: { type: Number, required: true }
});

// Product Schema
const productSchema = new mongoose.Schema({
    name: { type: String, required: true },
    price: { type: Number, required: true },
    category: { type: String, required: true },
    variants: [variantSchema]
});

const Product = mongoose.model('Product', productSchema);

// Add new product
app.post('/products', async (req, res) => {
    try {
        const product = new Product(req.body);
        await product.save();
        res.status(201).send(product);
    } catch (err) {
        res.status(400).send({ error: err.message });
    }
});

// Get all products
app.get('/products', async (req, res) => {
    try {
        const products = await Product.find();
        res.send(products);
    } catch (err) {
        res.status(500).send({ error: err.message });
    }
});

// Get products by category
app.get('/products/category/:category', async (req, res) => {
    try {
        const products = await Product.find({ category: req.params.category });
        res.send(products);
    } catch (err) {
        res.status(500).send({ error: err.message });
    }
});

// Get products by variant color
app.get('/products/by-color/:color', async (req, res) => {
    try {
        const products = await Product.find({ 'variants.color': req.params.color });
        res.send(products);
    } catch (err) {
        res.status(500).send({ error: err.message });
    }
});

app.listen(2000, () => console.log('Server running on port 2000'));